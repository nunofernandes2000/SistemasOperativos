/*
 * thread.c - counter thread
 */

#include <stdio.h>
#include <pthread.h>


int Counter = 0;

void* thr_incr(void* ptr)
{
   while (Counter < 20) {
      Counter++;
   }
   return NULL;
}

int main()
{
   pthread_t tid;
   if (pthread_create(&tid, NULL, thr_incr, NULL) != 0) {
      printf("Error creating thread.\n");
      return -1;
   }
   
   if(pthread_join(tid, NULL) != 0) {
      printf("Error joining thred.\n");
      return -1;
   }

   printf("Finished: Counter=%d\n",Counter);
   return 0;
}
